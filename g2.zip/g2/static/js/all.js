function disp()
{
    alert("mai hu javascript ");
}